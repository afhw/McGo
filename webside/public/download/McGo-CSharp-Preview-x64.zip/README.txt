McGo C# / WinUI 3 测试版
========================

版本：1.0.11 Preview
平台：Windows 10 1809 或更高版本，x64
构建日期：2026-07-15

使用方法
--------
1. 将 ZIP 完整解压到可写目录。
2. 运行 McGo.WinUI.exe。
3. 配置游戏目录、Java 和账号后开始使用。

这是 C# / .NET 8 / WinUI 3 迁移测试版，可能仍有未完成能力或兼容性问题。
请勿只复制 McGo.WinUI.exe；同目录 DLL 和资源文件均为运行所需依赖。

项目地址：https://github.com/afhw/McGo
